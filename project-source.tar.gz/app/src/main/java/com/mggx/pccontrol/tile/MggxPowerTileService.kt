package com.mggx.pccontrol.tile
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.content.Intent
import androidx.annotation.RequiresApi
import com.mggx.pccontrol.MainActivity
import com.mggx.pccontrol.data.*
import com.mggx.pccontrol.domain.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

@RequiresApi(24)
class MggxPowerTileService:TileService(){
    private val serviceScope=CoroutineScope(SupervisorJob()+Dispatchers.IO)
    override fun onClick(){super.onClick();serviceScope.launch{val store=SettingsStore(this@MggxPowerTileService);val s=store.settings.first();val api=if(s.demoMode)DemoRelayApi({s.simulatedStatus},{})else HttpRelayApi(store.config(s));val status=api.getStatus();if(status is RelayResult.Success&&status.value.state==PcState.ONLINE)withContext(Dispatchers.Main){startActivityAndCollapse(Intent(this@MggxPowerTileService,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}else api.wake();qsTile?.state=Tile.STATE_ACTIVE;qsTile?.updateTile()}}
    override fun onDestroy(){serviceScope.cancel();super.onDestroy()}
}
