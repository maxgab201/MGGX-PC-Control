package com.mggx.pccontrol.domain

enum class PcState { UNKNOWN, OFFLINE, WAKING, ONLINE, CONNECTING, ERROR }
enum class DemoStatus { OFFLINE, WAKING, ONLINE, ERROR }
enum class PowerAction { WAKE, SHUTDOWN, RESTART, SLEEP, HIBERNATE }
enum class RemoteAction(val path: String) { CAMERA("camera"), TERMINAL("terminal"), FILES("files"), ADMIN("admin"), TASK_MANAGER("task-manager"), LOCK("lock") }
data class Monitor(val id: String, val name: String, val active: Boolean = false)
data class PcInfo(val pcId: String, val name: String, val state: PcState, val lastSeen: Long? = null, val monitors: List<Monitor> = emptyList(), val message: String? = null)
data class RelayConfig(val url: String = "", val token: String = "", val pcId: String = "main", val timeoutSeconds: Int = 8) {
    fun normalizedUrl(): String = url.trim().trimEnd('/')
}
sealed class RelayResult<out T> { data class Success<T>(val value: T): RelayResult<T>(); data class Failure(val userMessage: String, val technical: String? = null): RelayResult<Nothing>() }

interface PcRelayApi {
    suspend fun getStatus(): RelayResult<PcInfo>
    suspend fun wake(): RelayResult<Unit>
    suspend fun shutdown(): RelayResult<Unit>
    suspend fun restart(): RelayResult<Unit>
    suspend fun sleep(): RelayResult<Unit>
    suspend fun hibernate(): RelayResult<Unit>
    suspend fun getPcInfo(): RelayResult<PcInfo> = getStatus()
    suspend fun getMonitors(): RelayResult<List<Monitor>>
    suspend fun activateMonitor(id: String): RelayResult<Unit>
    suspend fun action(action: RemoteAction): RelayResult<Unit>
}
