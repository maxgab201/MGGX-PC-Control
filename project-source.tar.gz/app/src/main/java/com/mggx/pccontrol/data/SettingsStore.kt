package com.mggx.pccontrol.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.mggx.pccontrol.domain.DemoStatus
import com.mggx.pccontrol.domain.RelayConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.dataStore by preferencesDataStore("mggx_settings")

data class AppSettings(
    val onboardingDone:Boolean=false,
    val demoMode:Boolean=false,
    val simulatedStatus:DemoStatus=DemoStatus.OFFLINE,
    val pcName:String="MGGX PC",
    val relayUrl:String="",
    val pcId:String="main",
    val timeoutSeconds:Int=8,
    val autoOpen:Boolean=false,
    val haptics:Boolean=true,
    val dynamicColors:Boolean=true,
)

class SettingsStore(private val context:Context){
    private object K { val onboarding=booleanPreferencesKey("onboarding");val demo=booleanPreferencesKey("demo");val status=stringPreferencesKey("demo_status");val name=stringPreferencesKey("pc_name");val url=stringPreferencesKey("relay_url");val pcId=stringPreferencesKey("pc_id");val timeout=intPreferencesKey("timeout");val autoOpen=booleanPreferencesKey("auto_open");val haptics=booleanPreferencesKey("haptics");val dynamic=booleanPreferencesKey("dynamic") }
    val settings:Flow<AppSettings> = context.dataStore.data.map{p->AppSettings(p[K.onboarding]?:false,p[K.demo]?:false,runCatching{DemoStatus.valueOf(p[K.status]?:"OFFLINE")}.getOrDefault(DemoStatus.OFFLINE),p[K.name]?:"MGGX PC",p[K.url]?:"",p[K.pcId]?:"main",p[K.timeout]?:8,p[K.autoOpen]?:false,p[K.haptics]?:true,p[K.dynamic]?:true)}
    suspend fun completeOnboarding(demo:Boolean){context.dataStore.edit{it[K.onboarding]=true;it[K.demo]=demo}}
    suspend fun saveRelay(url:String,pcId:String,timeout:Int){context.dataStore.edit{it[K.url]=url.trim();it[K.pcId]=pcId.trim().ifBlank{"main"};it[K.timeout]=timeout.coerceIn(2,60)}}
    suspend fun setDemo(enabled:Boolean){context.dataStore.edit{it[K.demo]=enabled}}
    suspend fun setDemoStatus(status:DemoStatus){context.dataStore.edit{it[K.status]=status.name}}
    suspend fun setAutoOpen(enabled:Boolean){context.dataStore.edit{it[K.autoOpen]=enabled}}
    fun config(settings:AppSettings)=RelayConfig(settings.relayUrl,SecureTokenStore(context).read().orEmpty(),settings.pcId,settings.timeoutSeconds)
}

class SecureTokenStore(context:Context){
    private val prefs=context.getSharedPreferences("mggx_secure",Context.MODE_PRIVATE)
    private val alias="mggx_relay_token_v1"
    private fun key():SecretKey{val ks=KeyStore.getInstance("AndroidKeyStore").apply{load(null)};(ks.getKey(alias,null) as? SecretKey)?.let{return it};return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").apply{init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())}.generateKey()}
    fun write(token:String){if(token.isBlank()){prefs.edit().clear().apply();return};val cipher=Cipher.getInstance("AES/GCM/NoPadding").apply{init(Cipher.ENCRYPT_MODE,key())};prefs.edit().putString("iv",android.util.Base64.encodeToString(cipher.iv,android.util.Base64.NO_WRAP)).putString("ciphertext",android.util.Base64.encodeToString(cipher.doFinal(token.toByteArray()),android.util.Base64.NO_WRAP)).apply()}
    fun read():String?=runCatching{val iv=android.util.Base64.decode(prefs.getString("iv",null),android.util.Base64.NO_WRAP);val data=android.util.Base64.decode(prefs.getString("ciphertext",null),android.util.Base64.NO_WRAP);String(Cipher.getInstance("AES/GCM/NoPadding").apply{init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,iv))}.doFinal(data))}.getOrNull()
}
