package com.mggx.pccontrol.data

import com.mggx.pccontrol.domain.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit
import org.json.JSONArray
import org.json.JSONObject

class DemoRelayApi(private val status: () -> DemoStatus, private val setStatus: (DemoStatus) -> Unit, private val wakeDelayMs: Long = 1_200): PcRelayApi {
    private var currentStatus = status()
    private var activeMonitor = "1"
    override suspend fun getStatus(): RelayResult<PcInfo> {
        if (currentStatus == DemoStatus.ERROR) return RelayResult.Failure("Error simulado del relay", "DEMO_ERROR")
        return RelayResult.Success(PcInfo("main", "MGGX PC", when(currentStatus) { DemoStatus.OFFLINE -> PcState.OFFLINE; DemoStatus.WAKING -> PcState.WAKING; DemoStatus.ONLINE -> PcState.ONLINE; DemoStatus.ERROR -> PcState.ERROR }, System.currentTimeMillis(), listOf(Monitor("1","Monitor 1",activeMonitor=="1"), Monitor("2","Monitor 2",activeMonitor=="2"))))
    }
    private fun transition(next:DemoStatus){currentStatus=next;setStatus(next)}
    override suspend fun wake(): RelayResult<Unit> { transition(DemoStatus.WAKING); delay(wakeDelayMs); transition(DemoStatus.ONLINE); return RelayResult.Success(Unit) }
    override suspend fun shutdown(): RelayResult<Unit> { delay(300); transition(DemoStatus.OFFLINE); return RelayResult.Success(Unit) }
    override suspend fun restart(): RelayResult<Unit> { transition(DemoStatus.WAKING); delay(800); transition(DemoStatus.ONLINE); return RelayResult.Success(Unit) }
    override suspend fun sleep(): RelayResult<Unit> = shutdown()
    override suspend fun hibernate(): RelayResult<Unit> = shutdown()
    override suspend fun getMonitors(): RelayResult<List<Monitor>> = getStatus().let { if (it is RelayResult.Success) RelayResult.Success(it.value.monitors) else RelayResult.Failure("No se pudieron obtener los monitores") }
    override suspend fun activateMonitor(id: String): RelayResult<Unit> = if(id in setOf("1","2")){activeMonitor=id;RelayResult.Success(Unit)}else RelayResult.Failure("Monitor desconocido")
    override suspend fun action(action: RemoteAction): RelayResult<Unit> = if(currentStatus==DemoStatus.ONLINE) RelayResult.Success(Unit) else RelayResult.Failure("La PC no está online")
}

class HttpRelayApi(private val config: RelayConfig): PcRelayApi {
    private val client = OkHttpClient.Builder().connectTimeout(config.timeoutSeconds.toLong(), TimeUnit.SECONDS).readTimeout(config.timeoutSeconds.toLong(), TimeUnit.SECONDS).callTimeout(config.timeoutSeconds.toLong() + 2, TimeUnit.SECONDS).followRedirects(false).followSslRedirects(false).build()
    private suspend fun request(path: String, method: String = "GET"): RelayResult<String> = withContext(Dispatchers.IO) { try {
        val base = config.normalizedUrl(); require(base.startsWith("https://") || base.startsWith("http://")) { "INVALID_SCHEME" }
        val req = Request.Builder().url("$base/api/v1/$path").method(method, if (method == "GET") null else "{}".toRequestBody("application/json".toMediaTypeOrNull())).apply { if (config.token.isNotBlank()) header("Authorization", "Bearer ${config.token}") }.build()
        client.newCall(req).execute().use { if (it.isSuccessful) RelayResult.Success(it.body?.string().orEmpty()) else RelayResult.Failure("El relay respondió con un error (${it.code})", "HTTP_${it.code}") }
    } catch (e: Exception) { RelayResult.Failure("No se pudo alcanzar el relay. Revisá Tailscale, el celular relay y la URL.", e.javaClass.simpleName) } }
    override suspend fun getStatus() = request("status").map { body -> parsePcInfo(body, config.pcId) }.flatten()
    override suspend fun wake() = unit("power/wake"); override suspend fun shutdown() = unit("power/shutdown"); override suspend fun restart() = unit("power/restart"); override suspend fun sleep() = unit("power/sleep"); override suspend fun hibernate() = unit("power/hibernate")
    private suspend fun unit(path:String): RelayResult<Unit> = request(path,"POST").map { RelayResult.Success(Unit) }.flatten()
    override suspend fun getMonitors() = request("monitors").map { body -> runCatching { RelayResult.Success(parseMonitors(JSONArray(body))) }.getOrElse { RelayResult.Failure("La respuesta de monitores no es válida", it.javaClass.simpleName) } }.flatten()
    override suspend fun activateMonitor(id:String) = unit("monitors/$id/activate")
    override suspend fun action(action:RemoteAction) = unit("actions/${action.path}")
}
internal fun parsePcInfo(body:String, fallbackPcId:String="main"): RelayResult<PcInfo> = runCatching {
    val j=JSONObject(body); val monitors = j.optJSONArray("monitors")?.let(::parseMonitors).orEmpty()
    RelayResult.Success(PcInfo(j.optString("pcId",fallbackPcId),j.optString("name","MGGX PC"),runCatching{PcState.valueOf(j.optString("state","unknown").uppercase())}.getOrDefault(PcState.UNKNOWN),j.optString("lastSeen").takeIf{it.isNotBlank()}?.let{runCatching{java.time.Instant.parse(it).toEpochMilli()}.getOrNull()},monitors,j.optString("message").takeIf{it.isNotBlank()}))
}.getOrElse { RelayResult.Failure("La respuesta del relay no es válida",it.javaClass.simpleName) }
internal fun parseMonitors(a:JSONArray):List<Monitor>=(0 until a.length()).map{index->a.getJSONObject(index)}.map{Monitor(it.getString("id"),it.optString("name","Monitor"),it.optBoolean("active",false))}
private fun <T,R> RelayResult<T>.map(f:(T)->RelayResult<R>): RelayResult<R> = when(this){ is RelayResult.Success -> f(value); is RelayResult.Failure -> this }
private fun <T> RelayResult<RelayResult<T>>.flatten(): RelayResult<T> = when(this){ is RelayResult.Success -> value; is RelayResult.Failure -> this }
