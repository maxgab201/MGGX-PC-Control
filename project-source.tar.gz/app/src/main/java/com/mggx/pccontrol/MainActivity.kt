package com.mggx.pccontrol

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mggx.pccontrol.data.*
import com.mggx.pccontrol.domain.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

private const val MOONLIGHT_PACKAGE="com.limelight"
private const val TAILSCALE_PACKAGE="com.tailscale.ipn"

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){installSplashScreen();super.onCreate(savedInstanceState);enableEdgeToEdge();publishShortcuts();setContent{MggxRoot()}}
    private fun publishShortcuts(){if(Build.VERSION.SDK_INT>=25){val sm=getSystemService(ShortcutManager::class.java);sm.dynamicShortcuts=listOf("wake" to "Prender PC","open" to "Abrir PC","status" to "Estado").map{(id,label)->ShortcutInfo.Builder(this,id).setShortLabel(label).setIcon(Icon.createWithResource(this,R.mipmap.ic_launcher)).setIntent(Intent(this,MainActivity::class.java).setAction("com.mggx.pccontrol.$id")).build()}}}
}

data class PcUiState(val settings:AppSettings=AppSettings(),val info:PcInfo=PcInfo("main","MGGX PC",PcState.UNKNOWN),val busy:Boolean=false,val wakeElapsed:Int=0,val lastError:String?=null,val lastLatencyMs:Long?=null,val toast:String?=null)

class PcViewModel(app:Application):AndroidViewModel(app){
    private val store=SettingsStore(app);private val secure=SecureTokenStore(app);private val _ui=MutableStateFlow(PcUiState());val ui:StateFlow<PcUiState> = _ui.asStateFlow();private var api:PcRelayApi?=null;private var wakeJob:Job?=null
    init{viewModelScope.launch{store.settings.collect{s->_ui.update{it.copy(settings=s,info=it.info.copy(name=s.pcName,pcId=s.pcId))};api=createApi(s)}}}
    private fun createApi(s:AppSettings):PcRelayApi=if(s.demoMode)DemoRelayApi({s.simulatedStatus},{next->viewModelScope.launch{store.setDemoStatus(next)}})else HttpRelayApi(store.config(s))
    fun finishOnboarding(demo:Boolean)=viewModelScope.launch{store.completeOnboarding(demo)}
    fun refresh()=viewModelScope.launch{refreshInternal()}
    private suspend fun refreshInternal():PcInfo?{val current=api?:return null;val start=SystemClock.elapsedRealtime();return when(val result=current.getStatus()){is RelayResult.Success->{_ui.update{it.copy(info=result.value,lastError=null,lastLatencyMs=SystemClock.elapsedRealtime()-start)};result.value};is RelayResult.Failure->{_ui.update{it.copy(info=it.info.copy(state=if(it.settings.demoMode)PcState.ERROR else PcState.UNKNOWN),lastError=result.userMessage,lastLatencyMs=null)};null}}}
    fun wake(autoOpen:(()->Unit)?=null){if(wakeJob?.isActive==true)return;wakeJob=viewModelScope.launch{_ui.update{it.copy(busy=true,wakeElapsed=0,lastError=null,info=it.info.copy(state=PcState.WAKING))};val result=api?.wake()?:RelayResult.Failure("Relay no configurado");if(result is RelayResult.Failure){_ui.update{it.copy(busy=false,lastError=result.userMessage,info=it.info.copy(state=PcState.ERROR))};return@launch};val started=SystemClock.elapsedRealtime();val timeout=_ui.value.settings.timeoutSeconds.coerceAtLeast(5)*1000L;while(SystemClock.elapsedRealtime()-started<timeout){val elapsed=((SystemClock.elapsedRealtime()-started)/1000).toInt();_ui.update{it.copy(wakeElapsed=elapsed)};val info=refreshInternal();if(info?.state==PcState.ONLINE){_ui.update{it.copy(busy=false,toast="MGGX PC está online")};if(_ui.value.settings.autoOpen)autoOpen?.invoke();return@launch};delay(1000)};_ui.update{it.copy(busy=false,lastError="La PC no respondió antes del timeout",info=it.info.copy(state=PcState.ERROR))}}}
    fun cancelWake(){wakeJob?.cancel();_ui.update{it.copy(busy=false,info=it.info.copy(state=PcState.UNKNOWN))}}
    fun activateMonitor(id:String)=viewModelScope.launch{when(val r=api?.activateMonitor(id)){is RelayResult.Failure->_ui.update{it.copy(lastError=r.userMessage)};else->refreshInternal()}}
    fun remoteAction(action:RemoteAction)=viewModelScope.launch{when(val r=api?.action(action)){is RelayResult.Failure->_ui.update{it.copy(lastError=r.userMessage)};else->_ui.update{it.copy(toast="Acción enviada")}}}
    fun power(action:PowerAction)=viewModelScope.launch{if(_ui.value.busy)return@launch;_ui.update{it.copy(busy=true)};val r=when(action){PowerAction.SHUTDOWN->api?.shutdown();PowerAction.RESTART->api?.restart();PowerAction.SLEEP->api?.sleep();PowerAction.HIBERNATE->api?.hibernate();PowerAction.WAKE->api?.wake()};if(r is RelayResult.Failure)_ui.update{it.copy(lastError=r.userMessage)};delay(250);refreshInternal();_ui.update{it.copy(busy=false)}}
    fun setDemo(enabled:Boolean)=viewModelScope.launch{store.setDemo(enabled)}
    fun setDemoStatus(status:DemoStatus)=viewModelScope.launch{store.setDemoStatus(status)}
    fun setAutoOpen(enabled:Boolean)=viewModelScope.launch{store.setAutoOpen(enabled)}
    fun saveRelay(url:String,token:String,pcId:String,timeout:Int)=viewModelScope.launch{secure.write(token);store.saveRelay(url,pcId,timeout);_ui.update{it.copy(toast="Configuración guardada")}}
    fun clearMessage(){_ui.update{it.copy(toast=null)}}
}

@Composable private fun MggxRoot(vm:PcViewModel=viewModel()){val ui by vm.ui.collectAsStateWithLifecycle();val dark=isSystemInDarkTheme();val colors=when{ui.settings.dynamicColors&&Build.VERSION.SDK_INT>=31->if(dark)dynamicDarkColorScheme(LocalContext.current)else dynamicLightColorScheme(LocalContext.current);dark->darkColorScheme(primary=Color(0xFFB9C3FF));else->lightColorScheme(primary=Color(0xFF4255D4))};MaterialTheme(colorScheme=colors){if(!ui.settings.onboardingDone)Onboarding(vm)else MainShell(ui,vm)}}

@Composable private fun Onboarding(vm:PcViewModel){var page by remember{mutableIntStateOf(0)};Surface(Modifier.fillMaxSize()){Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.SpaceBetween){Column(verticalArrangement=Arrangement.spacedBy(18.dp)){Icon(Icons.Default.DesktopWindows,null,Modifier.size(72.dp),MaterialTheme.colorScheme.primary);Text("MGGX PC Control",style=MaterialTheme.typography.displaySmall,fontWeight=FontWeight.Bold);Text(if(page==0)"Tu PC, desde cualquier lugar." else "Necesitás Tailscale, Moonlight, un relay en casa y Sunshine en tu PC.",style=MaterialTheme.typography.titleLarge,color=MaterialTheme.colorScheme.onSurfaceVariant)};Column(verticalArrangement=Arrangement.spacedBy(10.dp)){if(page==0)Button({page=1},Modifier.fillMaxWidth()){Text("CONTINUAR")}else{Button({vm.finishOnboarding(false)},Modifier.fillMaxWidth()){Text("CONFIGURAR AHORA")};OutlinedButton({vm.finishOnboarding(true)},Modifier.fillMaxWidth()){Text("USAR MODO DEMO")}}}}}}

@Composable private fun MainShell(ui:PcUiState,vm:PcViewModel){var tab by remember{mutableIntStateOf(0)};val context=LocalContext.current;ui.toast?.let{LaunchedEffect(it){delay(1800);vm.clearMessage()}};Scaffold(bottomBar={NavigationBar{listOf(Icons.Default.Computer to "PC",Icons.Default.Info to "Diagnóstico",Icons.Default.Settings to "Ajustes").forEachIndexed{i,(icon,label)->NavigationBarItem(selected=i==tab,onClick={tab=i},icon={Icon(icon,null)},label={Text(label)})}}}){padding->Box(Modifier.padding(padding)){when(tab){0->Home(ui,vm,{openPackage(context,MOONLIGHT_PACKAGE)});1->Diagnostics(ui,vm);else->Settings(ui,vm)}}}}

@Composable private fun Home(ui:PcUiState,vm:PcViewModel,openMoonlight:()->Unit){var confirmation by remember{mutableStateOf<PowerAction?>(null)};confirmation?.let{action->AlertDialog(onDismissRequest={confirmation=null},title={Text("¿${actionLabel(action)} MGGX PC?")},text={Text("Esta acción puede cerrar la sesión remota.")},confirmButton={Button({confirmation=null;vm.power(action)}){Text(actionLabel(action).uppercase())}},dismissButton={TextButton({confirmation=null}){Text("CANCELAR")}})};LazyColumn(Modifier.fillMaxSize().padding(horizontal=20.dp),contentPadding=PaddingValues(top=24.dp,bottom=32.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("MGGX PC Control",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);if(ui.settings.demoMode)Text("MODO DEMO",color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold)};IconButton({vm.refresh()}){Icon(Icons.Default.Refresh,"Actualizar estado")}}};item{PcPanel(ui,vm,openMoonlight)};item{SectionTitle("Monitores")};item{if(ui.info.monitors.isEmpty())Text("Los monitores aparecerán cuando el servicio PC responda.",color=MaterialTheme.colorScheme.onSurfaceVariant)else LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(ui.info.monitors,key={it.id}){m->FilterChip(selected=m.active,onClick={vm.activateMonitor(m.id)},label={Text(m.name)},leadingIcon=if(m.active){{Icon(Icons.Default.Check,null)}}else null)}}};item{SectionTitle("Acciones rápidas")};item{LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(listOf(RemoteAction.CAMERA to Icons.Default.CameraAlt,RemoteAction.TERMINAL to Icons.Default.Terminal,RemoteAction.FILES to Icons.Default.Folder,RemoteAction.TASK_MANAGER to Icons.Default.Memory)){(action,icon)->AssistChip(onClick={vm.remoteAction(action)},enabled=ui.info.state==PcState.ONLINE,label={Text(actionName(action))},leadingIcon={Icon(icon,null)})}}};item{SectionTitle("Energía")};item{LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(listOf(PowerAction.RESTART,PowerAction.SLEEP,PowerAction.HIBERNATE,PowerAction.SHUTDOWN)){a->OutlinedButton({confirmation=a},enabled=!ui.busy){Text(actionLabel(a))}}}};ui.lastError?.let{item{ErrorCard(it,{vm.refresh()})}}}}

@Composable private fun PcPanel(ui:PcUiState,vm:PcViewModel,openMoonlight:()->Unit){ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(22.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(ui.info.name,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Status(ui.info.state)};Icon(Icons.Default.DesktopWindows,null,Modifier.size(52.dp),MaterialTheme.colorScheme.primary)};if(ui.info.state==PcState.WAKING){LinearProgressIndicator(Modifier.fillMaxWidth());Text("Esperando que Windows responda · ${ui.wakeElapsed} s");OutlinedButton({vm.cancelWake()},Modifier.fillMaxWidth()){Text("CANCELAR")}}else{Button({vm.wake(openMoonlight)},enabled=!ui.busy&&ui.info.state!=PcState.ONLINE,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.PowerSettingsNew,null);Spacer(Modifier.width(8.dp));Text("Prender PC")};OutlinedButton(openMoonlight,Modifier.fillMaxWidth(),enabled=ui.info.state==PcState.ONLINE){Icon(Icons.Default.OpenInNew,null);Spacer(Modifier.width(8.dp));Text("Abrir en Moonlight")}}}}}

@Composable private fun Diagnostics(ui:PcUiState,vm:PcViewModel){val context=LocalContext.current;val rows=listOf("Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})","Aplicación" to BuildConfig.VERSION_NAME,"Tailscale" to installedLabel(context,TAILSCALE_PACKAGE),"Moonlight" to installedLabel(context,MOONLIGHT_PACKAGE),"Relay configurado" to if(ui.settings.relayUrl.isBlank())"No" else "Sí","PC" to ui.info.state.name,"Latencia" to (ui.lastLatencyMs?.let{"${it} ms"}?:"—"),"Último error" to (ui.lastError?:"—"));LazyColumn(Modifier.fillMaxSize().padding(horizontal=20.dp),contentPadding=PaddingValues(top=24.dp,bottom=32.dp)){item{Text("Diagnóstico",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)};items(rows){(a,b)->ListItem(headlineContent={Text(a)},supportingContent={Text(b)})};item{Button({vm.refresh()},Modifier.fillMaxWidth()){Text("EJECUTAR DIAGNÓSTICO")}};item{Spacer(Modifier.height(8.dp));OutlinedButton({copyReport(context,rows)},Modifier.fillMaxWidth()){Text("COPIAR REPORTE SANITIZADO")}}}}

@Composable private fun Settings(ui:PcUiState,vm:PcViewModel){val context=LocalContext.current;var url by remember(ui.settings.relayUrl){mutableStateOf(ui.settings.relayUrl)};var token by remember{mutableStateOf("")};var pcId by remember(ui.settings.pcId){mutableStateOf(ui.settings.pcId)};var timeout by remember(ui.settings.timeoutSeconds){mutableStateOf(ui.settings.timeoutSeconds.toString())};LazyColumn(Modifier.fillMaxSize().padding(horizontal=20.dp),contentPadding=PaddingValues(top=24.dp,bottom=32.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("Ajustes",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)};item{SectionTitle("Relay")};item{OutlinedTextField(url,{url=it},Modifier.fillMaxWidth(),label={Text("URL del relay")},singleLine=true)};item{OutlinedTextField(token,{token=it},Modifier.fillMaxWidth(),label={Text("API token")},singleLine=true)};item{OutlinedTextField(pcId,{pcId=it},Modifier.fillMaxWidth(),label={Text("PC ID")},singleLine=true)};item{OutlinedTextField(timeout,{timeout=it.filter(Char::isDigit)},Modifier.fillMaxWidth(),label={Text("Timeout (segundos)")},singleLine=true)};item{Button({vm.saveRelay(url,token,pcId,timeout.toIntOrNull()?:8)},Modifier.fillMaxWidth()){Text("GUARDAR")}};item{SectionTitle("Remote Desktop")};item{ListItem(headlineContent={Text("Moonlight")},supportingContent={Text(installedLabel(context,MOONLIGHT_PACKAGE))},trailingContent={TextButton({openPackage(context,MOONLIGHT_PACKAGE)}){Text("ABRIR")}})};item{ListItem(headlineContent={Text("Prender y conectar automáticamente")},trailingContent={Switch(ui.settings.autoOpen,{vm.setAutoOpen(it)})})};item{SectionTitle("Tailscale")};item{OutlinedButton({openPackage(context,TAILSCALE_PACKAGE)},Modifier.fillMaxWidth()){Text("ABRIR TAILSCALE")}};item{SectionTitle("Desarrollador")};item{ListItem(headlineContent={Text("Modo Demo")},supportingContent={Text("Simula el relay y la PC localmente")},trailingContent={Switch(ui.settings.demoMode,{vm.setDemo(it)})})};if(ui.settings.demoMode)item{LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(DemoStatus.entries){s->FilterChip(selected=s==ui.settings.simulatedStatus,onClick={vm.setDemoStatus(s)},label={Text(s.name)})}}}}}

@Composable private fun Status(state:PcState){val(color,label)=when(state){PcState.ONLINE->Color(0xFF2E9D62) to "ONLINE";PcState.WAKING->Color(0xFFDB8B00) to "WAKING";PcState.ERROR->MaterialTheme.colorScheme.error to "ERROR";PcState.CONNECTING->MaterialTheme.colorScheme.primary to "CONNECTING";PcState.OFFLINE->MaterialTheme.colorScheme.outline to "OFFLINE";PcState.UNKNOWN->MaterialTheme.colorScheme.outline to "UNKNOWN"};Row(verticalAlignment=Alignment.CenterVertically){Text("●",color=color);Spacer(Modifier.width(6.dp));Text(label,color=color,fontWeight=FontWeight.Bold)}}
@Composable private fun SectionTitle(text:String)=Text(text,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
@Composable private fun ErrorCard(message:String,retry:()->Unit)=Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.errorContainer)){Column(Modifier.padding(16.dp)){Text(message,color=MaterialTheme.colorScheme.onErrorContainer);TextButton(retry){Text("REINTENTAR")}}}
private fun actionLabel(a:PowerAction)=when(a){PowerAction.WAKE->"Prender";PowerAction.SHUTDOWN->"Apagar";PowerAction.RESTART->"Reiniciar";PowerAction.SLEEP->"Suspender";PowerAction.HIBERNATE->"Hibernar"}
private fun actionName(a:RemoteAction)=when(a){RemoteAction.CAMERA->"Cámara";RemoteAction.TERMINAL->"Terminal";RemoteAction.FILES->"Archivos";RemoteAction.ADMIN->"Administrador";RemoteAction.TASK_MANAGER->"Task Manager";RemoteAction.LOCK->"Bloquear"}
private fun installed(context:Context,pkg:String)=try{context.packageManager.getPackageInfo(pkg,0);true}catch(_:Exception){false}
private fun installedLabel(context:Context,pkg:String)=if(installed(context,pkg))"Instalado" else "No instalado"
private fun openPackage(context:Context,pkg:String){val launch=context.packageManager.getLaunchIntentForPackage(pkg);val intent=launch?:Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id=$pkg"));runCatching{context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}.onFailure{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id=$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}}
private fun copyReport(context:Context,rows:List<Pair<String,String>>){val report=rows.joinToString("\n"){"${it.first}: ${it.second}"};(context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("MGGX diagnostics",report))}
