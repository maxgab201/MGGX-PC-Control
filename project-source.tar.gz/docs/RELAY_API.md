# MGGX Relay API v1

Base URL is configured by the user; no address is hardcoded. Requests use `Authorization: Bearer <token>` when a token is configured.

Endpoints:

- `GET /api/v1/status` → `{ pcId, name, state, lastSeen, monitors }`
- `POST /api/v1/power/wake|shutdown|restart|sleep|hibernate`
- `GET /api/v1/monitors`
- `POST /api/v1/monitors/{id}/activate`
- `POST /api/v1/actions/camera|terminal|files|task-manager`

Only explicit allow-listed actions are exposed by the client. The client never sends arbitrary commands. Network errors are translated into user-facing messages and technical details stay out of normal UI.
